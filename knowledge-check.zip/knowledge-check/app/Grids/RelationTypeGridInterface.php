<?php

namespace App\Grids;

use Leantony\Grid\GridInterface;

interface RelationTypeGridInterface extends GridInterface
{
    //
}