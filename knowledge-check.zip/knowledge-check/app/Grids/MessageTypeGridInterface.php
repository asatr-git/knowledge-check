<?php

namespace App\Grids;

use Leantony\Grid\GridInterface;

interface MessageTypeGridInterface extends GridInterface
{
    //
}