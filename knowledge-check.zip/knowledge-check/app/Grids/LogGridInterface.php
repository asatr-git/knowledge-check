<?php

namespace App\Grids;

use Leantony\Grid\GridInterface;

interface LogGridInterface extends GridInterface
{
    //
}