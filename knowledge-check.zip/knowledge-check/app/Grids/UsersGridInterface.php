<?php

namespace App\Grids;

use Leantony\Grid\GridInterface;

interface UsersGridInterface extends GridInterface
{
    //
}