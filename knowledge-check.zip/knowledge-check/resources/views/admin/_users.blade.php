@extends('admin.main')

@section('content')
  {!! $grid !!}
@endsection
 

