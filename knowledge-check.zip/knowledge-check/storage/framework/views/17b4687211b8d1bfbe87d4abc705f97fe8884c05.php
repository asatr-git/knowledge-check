<input type="text" name="<?php echo e($name); ?>" id="<?php echo e($id); ?>"
       form="<?php echo e($formId); ?>"
       class="<?php echo e($class); ?>" value="<?php echo e(request($name)); ?>" title="<?php echo e($title); ?>" placeholder="<?php echo e($title); ?>"
       <?php $__currentLoopData = $dataAttributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       data-<?php echo e($k); ?>=<?php echo e($v); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
>