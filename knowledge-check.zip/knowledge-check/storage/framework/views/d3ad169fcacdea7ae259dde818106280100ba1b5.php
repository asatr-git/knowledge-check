<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><h4>Добавить ответы на вопрос  "<?php echo e($question->name); ?>"</h4></div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/admin/answer-bulkadd')); ?>">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="question_id" value="<?php echo e($question->id); ?>">

                        <?php for($i = 0; $i < 5; $i++): ?> 
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Ответ</label>
                            <div class="col-md-12">
                                <textarea class="form-control" name="answer_name<?php echo e($i); ?>" cols="150" rows="2"></textarea>
                            </div>
                        </div>
                        <?php endfor; ?>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Save
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>