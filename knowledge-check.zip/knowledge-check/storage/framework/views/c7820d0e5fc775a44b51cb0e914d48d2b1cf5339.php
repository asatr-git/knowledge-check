<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><h4><?php echo e($article[0]->name); ?></h1></div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('admin/article-body')); ?>">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" value="<?php echo e($article[0]->id); ?>">

                        <div class="form-group">
                            <div class="col-md-12">
                                <textarea class="summernote" name="body" id="" cols="130" rows="10"><?php echo e($article[0]->body); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-sign-in"></i>Save
                                </button>
                                <a href="/admin/article">
                                    <button class="btn btn-primary"><i class="fa fa-btn fa-sign-in"></i>Cancel</button>
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- include summernote css/js -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.js"></script>

<script>
$(document).ready(function() {
    $('.summernote').summernote({
    height: 350,
  });  
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>