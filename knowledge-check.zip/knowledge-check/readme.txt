1. Скопировать папку knowledge-check на сервер.
2. Настроить корневую папку web сервера на knowledge-check/public.
3. Выполнить knowledge_check.sql.